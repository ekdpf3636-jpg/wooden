export const UserArrays = [
  { id : 1, name: "이름", value: "userName", type:"text"},
  { id : 2, name: "아이디" , value : "loginId", type:"email" },
  { id : 3, name: "비밀번호", value : "password", type: "password",},
  { id : 4, name: "비밀번호 확인", value : "checkPassword", type: "password"}
];