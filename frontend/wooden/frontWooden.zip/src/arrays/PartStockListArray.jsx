export const PartStockListArray = [
  { id: "1", clmn: "psNo", content: "재고ID", align: "center" },
  { id: "2", clmn: "partName", content: "부품명", align: "center"},
  { id: "3", clmn: "psQty", content: "재고수량", align: "right" },
];
