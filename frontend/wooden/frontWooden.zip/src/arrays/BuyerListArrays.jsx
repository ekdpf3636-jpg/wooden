export const buyerCustomerArray = [            
  { id: 1, clmn: "buyerNo", input: "number",content: "구매처 번호" },
  { id: 2, clmn: "buyerComp", input: "text", content: "구매처명" },
  { id: 3, clmn: "buyerName", input: "text", content: "담당자" },
  { id: 4, clmn: "buyerEmail", input: "text", content: "이메일" },
  { id: 5, clmn: "buyerPhone", input: "text", content: "구매처 전화번호" },
  { id: 6, clmn: "buyerAddr", input: "text", content: "구매처주소" },
];